/*
  Check if variable is defined
*/

class VarCheck{
    public static void main(String[] a){
        System.out.println(new Test1().Something());
    }
}

class Test1 {

    public int Something(){
	boolean bVal1;
	int [] arr1;

	System.out.println(new Test3());
	bVal1 = true;
	bVal2 = false;
        return 0;
    }
}

class Test2 extends Test1{
    int iVal3;
    int iVal4;
    int [] arr1;
    boolean bVal1;

    public int SomethingMore(){
	iVal3 = iVal4 * iVal5;
	arr2[1] = 5;
	return 0;
    }
}

