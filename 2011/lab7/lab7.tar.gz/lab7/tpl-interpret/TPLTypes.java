public class TPLTypes {
  public static final int 
     intType = 0,
     boolType = 1,
     decType =2,
     stmType = 3;
}
