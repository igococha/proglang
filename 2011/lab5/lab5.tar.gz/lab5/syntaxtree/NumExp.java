package syntaxtree;

public class NumExp  extends Exp {
    public int v;
    public String s;
    public NumExp (String s) { v=Integer.parseInt(s); }
  public int evaluate() { 
    return 0;
  }
}
