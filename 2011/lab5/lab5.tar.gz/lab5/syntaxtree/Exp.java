package syntaxtree;

public abstract class Exp {
  public abstract int evaluate();
}
