
public class LexerException extends Exception {
    public LexerException() { }
    public LexerException(String msg) { super(msg); }

}