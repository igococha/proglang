
public enum TokenKind { ERROR, INTEGER, PLUS, MINUS, MULT, DIV }