
public class Token {
    public Token(String i, TokenKind k) {
	image = i;
	kind = k;
    }
    public String image;
    public TokenKind kind;
}